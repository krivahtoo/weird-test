import{default as t}from"../entry/error.svelte.d1ada3d1.js";export{t as component};
